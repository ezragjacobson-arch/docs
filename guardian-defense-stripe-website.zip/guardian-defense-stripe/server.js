const express = require('express');
const Stripe = require('stripe');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4242;
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

if (!stripeSecretKey) {
  console.warn('STRIPE_SECRET_KEY is not set. Add it to your environment before taking payments.');
}

const stripe = stripeSecretKey ? new Stripe(stripeSecretKey) : null;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const products = {
  fundamentals: { name: 'Self-Defense Fundamentals', amount: 14900 },
  deescalation: { name: 'De-Escalation & Personal Safety', amount: 11900 },
  firearms: { name: 'Firearms Safety', amount: 9900 },
  handtohand: { name: 'Hand-to-Hand Fundamentals', amount: 17900 },
  single: { name: 'Single Class', amount: 2500 },
  monthly: { name: 'Monthly Training', amount: 7900 },
  program: { name: '8-Week Program', amount: 14900 }
};

app.post('/api/create-checkout-session', async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ error: 'Stripe is not configured yet. Add STRIPE_SECRET_KEY to the server environment.' });

    const { name, email, phone, selection, startDate, message } = req.body || {};
    if (!name || !email || !selection) return res.status(400).json({ error: 'Name, email, and class/plan are required.' });

    const product = products[selection];
    if (!product) return res.status(400).json({ error: 'Invalid class or plan selected.' });

    const origin = `${req.protocol}://${req.get('host')}`;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: email,
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: { name: product.name },
          unit_amount: product.amount
        },
        quantity: 1
      }],
      metadata: {
        registration_name: String(name).slice(0, 500),
        registration_phone: String(phone || '').slice(0, 500),
        registration_selection: product.name,
        preferred_start_date: String(startDate || '').slice(0, 500),
        registration_message: String(message || '').slice(0, 500)
      },
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/#register`
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Unable to create checkout session.' });
  }
});

app.get('/api/checkout-session/:id', async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ error: 'Stripe is not configured.' });
    const session = await stripe.checkout.sessions.retrieve(req.params.id);
    res.json({
      paid: session.payment_status === 'paid',
      customerEmail: session.customer_details?.email || session.customer_email || '',
      amountTotal: session.amount_total,
      currency: session.currency,
      item: session.metadata?.registration_selection || ''
    });
  } catch (error) {
    res.status(400).json({ error: 'Unable to retrieve checkout session.' });
  }
});

app.listen(PORT, () => console.log(`Guardian Defense running on port ${PORT}`));

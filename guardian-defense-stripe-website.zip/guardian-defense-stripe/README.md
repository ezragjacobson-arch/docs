# Guardian Defense — Stripe Registration Website

This version adds a real Stripe Checkout integration to the Guardian Defense registration website.

## What it does
- Customer selects a Guardian Defense class or plan.
- Customer enters registration details.
- The server creates a secure Stripe Checkout Session.
- Customer is redirected to Stripe's hosted checkout page.
- Registration details are attached to the Stripe transaction as metadata.
- A success page confirms payment status.
- Your Stripe Dashboard can be used to review payments and the registration metadata.

## IMPORTANT: Stripe secret key
Never put a Stripe secret key in `index.html`, `script.js`, GitHub Pages, or any browser-side file.

1. Create/activate your Stripe account.
2. Copy `.env.example` to `.env`.
3. Put your Stripe secret key in `STRIPE_SECRET_KEY`.
4. Run `npm install`.
5. Run `npm start`.
6. Open the local URL shown by the server.

For testing, use Stripe's test-mode secret key. Switch to a live secret key only after testing.

## Pricing
The amounts currently in the code are the placeholder prices from the previous Guardian Defense website:
- Self-Defense Fundamentals — $149
- De-Escalation & Personal Safety — $119
- Firearms Safety — $99
- Hand-to-Hand Fundamentals — $179
- Single Class — $25
- Monthly Training — $79
- 8-Week Program — $149

Confirm your actual business prices before going live.

## Hosting
Because Stripe Checkout Sessions are created server-side, this version needs a host that can run Node.js/server-side code. GitHub Pages alone cannot run `server.js`.

Suitable deployment options include a Node-capable host or serverless platform. Set `STRIPE_SECRET_KEY` as a server environment variable there.

## Stripe fees
Stripe's current standard U.S. pricing lists no setup or monthly fees and 2.9% + $0.30 per successful domestic card transaction. See Stripe's current pricing for the latest rates.

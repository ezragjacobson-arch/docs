const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
if (menuButton && nav) menuButton.addEventListener('click', () => nav.classList.toggle('open'));

document.querySelectorAll('[data-selection]').forEach(button => {
  button.addEventListener('click', () => {
    const select = document.getElementById('selection');
    if (select) {
      select.value = button.dataset.selection;
      document.getElementById('register')?.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

const form = document.getElementById('registration-form');
const message = document.getElementById('form-message');
if (form) {
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const submit = form.querySelector('button[type="submit"]');
    const data = Object.fromEntries(new FormData(form).entries());
    if (!document.getElementById('acknowledge')?.checked) {
      if (message) message.textContent = 'Please acknowledge the registration, safety, and legal requirements.';
      return;
    }
    submit.disabled = true;
    submit.textContent = 'Connecting to secure checkout...';
    if (message) message.textContent = '';
    try {
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Unable to start checkout.');
      window.location.href = result.url;
    } catch (error) {
      if (message) message.textContent = error.message;
      submit.disabled = false;
      submit.textContent = 'Continue to secure payment';
    }
  });
}
